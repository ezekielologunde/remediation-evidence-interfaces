# Auditor obligation audit

Technical case-study preprint candidate. No journal acceptance, new-method priority,
independent requirement adjudication or model-performance result is claimed.

## Compile
Set main.tex as the Overleaf main document. It is self-contained, with inline
bibliography and TikZ/pgfplots figures. Select XeLaTeX. Local verification used
Tectonic 0.17.0, XeTeX 0.999994, acmart 1.83 (2022), sigconf,nonacm.
The current Overleaf service and a different TeX distribution were not tested.

## Check values without the solver
python verification/src/verify_clinical_release.py --source main.tex --receipt verification/analysis/clinical-family/receipt.json

## Reproduce the native audit on Windows
Install official experimental Cedar CLI 4.13.0 and CVC5 1.4.2. Put their extracted
directories below verification/.local-tools/cedar and verification/.local-tools/cvc5.
Run python verification/src/clinical_family_audit.py. It downloads pinned schemas,
plans and references as data, records hashes, and does not execute upstream Python.
It requires internet access. The receipt retains the original machine's command
paths for provenance; the script computes paths for a new extraction.
The earlier motivating request can be rerun with native_consent_audit.py using
its explicit --cedar and --cvc5 arguments. No model API or HPC is required.

## Rights and interpretation
Derived floor-union policies retain the upstream license and notice under
verification/analysis/clinical-family/. Original work is unlicensed pending the
author's decision. This archive excludes downloaded papers and tool binaries.
The family is a selected, related set. The 34 omitted probes are logical slices,
not 34 independent tasks, actual model mistakes or a population failure rate.
Available released clinical outputs cover all 40 positive probes. Their summary
points to an unavailable final inspected directory; final paper outputs are not
asserted. The document-sharing transfer is one base case with two probes.
Run python verification/src/verify_followup_release.py verification main.tex
to check follow-up values and hashes. Native follow-ups can be rerun after the
clinical audit with released_clinical_audit.py and doccloud_transfer_audit.py.
